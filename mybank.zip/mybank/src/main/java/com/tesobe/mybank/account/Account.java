package com.tesobe.mybank.account;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.tesobe.mybank.Application;
import com.tesobe.mybank.MoneyJson;
import lombok.Data;
import org.joda.money.Money;

@Data
public class Account {
    private String id;
    private String label;
    @JsonProperty("bank_id")
    private String bankId;

    @JsonDeserialize(using = MoneyJson.MoneyDeserializer.class)
    private Money balance;

    private String type;

    @JsonProperty("IBAN")
    private String iban;

    @JsonProperty("swist_bic")
    private String bic;
    
    /*public Account(){
    	
    }*/

	public String getId() {
		return id;
	}

	public String getLabel() {
		return label;
	}

	public String getBankId() {
		return bankId;
	}

	public Money getBalance() {
		return balance;
	}

	public String getType() {
		return type;
	}

	public String getIban() {
		return iban;
	}

	public String getBic() {
		return bic;
	}
	
	@Data
	public class View{
		
		@JsonProperty("name")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
        private String name;
		
		@JsonProperty("description")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
		private String description;
		
		@JsonProperty("is_public")
        @JsonFormat(shape = JsonFormat.Shape.BOOLEAN, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
		private boolean isPublic;
		
		@JsonProperty("which_alias_to_use")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
		private String aliasName;
		
		@JsonProperty("hide_metadata_if_alias_used")
        @JsonFormat(shape = JsonFormat.Shape.BOOLEAN, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
		private boolean hideMetadata;
		
		@JsonProperty("allowed_actions")
        @JsonFormat(shape = JsonFormat.Shape.ARRAY, pattern = Application.ISO8601_TIMESTAMP_FORMAT, timezone = "UTC")
		private String[] allowedActions;
		
		public View(){
			
		}

		public String getName() {
			return name;
		}

		public String getDescription() {
			return description;
		}

		public boolean isPublic() {
			return isPublic;
		}

		public void setPublic(boolean isPublic) {
			this.isPublic = isPublic;
		}

		public String getAliasName() {
			return aliasName;
		}

		public void setAliasName(String aliasName) {
			this.aliasName = aliasName;
		}

		public boolean isHideMetadata() {
			return hideMetadata;
		}

		public void setHideMetadata(boolean hideMetadata) {
			this.hideMetadata = hideMetadata;
		}

		public String[] getAllowedActions() {
			return allowedActions;
		}

		public void setAllowedActions(String[] allowedActions) {
			this.allowedActions = allowedActions;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setDescription(String description) {
			this.description = description;
		}
		
	}
}
