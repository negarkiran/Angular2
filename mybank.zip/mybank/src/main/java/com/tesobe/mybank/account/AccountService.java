package com.tesobe.mybank.account;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.tesobe.mybank.account.Account.View;

@Component
public class AccountService {
    @Value("${obp.api.versionedUrl}/my/accounts")
    private String privateAccountUrl;

    @Value("${obp.api.versionedUrl}")
    private String apiUrl;

    private RestTemplate restTemplate = new RestTemplate();

    public List<Account> fetchPrivateAccounts(String token, boolean withDetails) {
        HttpEntity<Void> req = prepareAuthRequest(token,null);
        Account[] accounts = restTemplate.exchange(privateAccountUrl, HttpMethod.GET, req,  Account[].class).getBody();

        if(!withDetails) {
            return Arrays.asList(accounts);
        }

        return Stream.of(accounts).map(account -> {
            String acctDetailsUrl = String.format("%s/my/banks/%s/accounts/%s/account", apiUrl, account.getBankId(), account.getId());
            return restTemplate.exchange(acctDetailsUrl, HttpMethod.GET, req, Account.class).getBody();
        }).collect(Collectors.toList());
    }
    
    public List<View> fetchAccountViews(String token){
    	HttpEntity<Void> req = prepareAuthRequest(token,null);
    	List<Account> accounts = fetchPrivateAccounts(token, true);
    	List<View> views = new ArrayList<>();
    	for(Account account:accounts){
    		String accountViewsUrl = String.format("%s/banks/%s/accounts/%s/views",apiUrl,account.getBankId(),account.getId());
    		views.add(restTemplate.exchange(accountViewsUrl, HttpMethod.GET,req,View.class).getBody());
    	}
    	return views;
    }
    
    public void createViewForBankAcocount(String token,Account account){
    	String createViewUrl = String.format("%s/banks/%s/accounts/%s/views", apiUrl,account.getBankId(),account.getId());
    	View createView = account.new View();
    	createView.setName(account.getId()+"_view");
    	createView.setDescription("View for Account"+account.getId());
    	createView.setPublic(false);
    	createView.setAliasName("test");
    	createView.setHideMetadata(true);
    	createView.setAllowedActions(new String[]{"test"});
    	HttpEntity<View> req = prepareAuthRequest(token,createView);
    	ResponseEntity<View> response = restTemplate.exchange(createViewUrl, HttpMethod.POST,req, View.class);
    	System.out.println(response.getStatusCodeValue());
    }

    private <T> HttpEntity<T> prepareAuthRequest(String token,T body) {
        HttpHeaders authHeaders = new HttpHeaders();
        String dlHeader = String.format("DirectLogin token=%s", token);
        authHeaders.add(HttpHeaders.AUTHORIZATION, dlHeader);
        return new HttpEntity<>(body, authHeaders);
    }
}
