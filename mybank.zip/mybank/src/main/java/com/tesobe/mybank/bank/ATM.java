package com.tesobe.mybank.bank;

public class ATM {

}
