package com.tesobe.mybank.bank;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tesobe.mybank.auth.DirectAuthenticationService;

@RestController
@RequestMapping("/api")
public class BankController {

	@Autowired
	private BankService bankService;
	
	@Autowired
	private DirectAuthenticationService directAuthenticationService;
	
	@Value("${obp.username}")
    private String username;

    @Value("${obp.password}")
    private String password;

    @RequestMapping(value="/banks", method=RequestMethod.GET)
	public List<Bank> getBanks(){
		return bankService.fetchBankDetails(getAuthToken());
	}
	
	private String getAuthToken(){
		return directAuthenticationService.login(username, password);
	}
}
