package com.tesobe.mybank.bank;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class BankService {
	
	@Value("${obp.api.versionedUrl}/banks")
	private String bankUrl;
	
	private RestTemplate restTemplate = new RestTemplate();
	
	public List<Bank> fetchBankDetails(String token){
		HttpEntity<Void> req = prepareAuthRequest(token);
		List<Bank> banks = restTemplate.exchange(bankUrl, HttpMethod.GET, req, Banks.class).getBody().getBanks();
		return banks;
	}
	
	private HttpEntity<Void> prepareAuthRequest(String token){
		HttpHeaders authHeaders = new HttpHeaders();
		String dlHeader = String.format("DirectLogin token =%s", token);
		authHeaders.add(HttpHeaders.AUTHORIZATION, dlHeader);
		return new HttpEntity<>(null,authHeaders);
	}
	
}
