package com.tesobe.mybank.bank;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Banks {
	
	@JsonProperty("banks")
	private List<Bank> banks;

	public List<Bank> getBanks() {
		return banks;
	}
	
}
