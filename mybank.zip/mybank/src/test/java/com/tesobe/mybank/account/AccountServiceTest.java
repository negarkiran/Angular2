package com.tesobe.mybank.account;

import com.tesobe.mybank.AbstractTestSupport;
import com.tesobe.mybank.account.Account.View;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountServiceTest extends AbstractTestSupport {

    @Autowired private AccountService accountService;

    @Test
    public void fetchPrivateAccountsNoDetailsOk() {
        //fetch private accounts
        List<Account> privateAccounts = accountService.fetchPrivateAccounts(authToken, false);
        assertTrue(privateAccounts.size() > 0);
    }

    @Test
    public void fetchPrivateAccountsWithDetailsOk() {
        //fetch private accounts
        List<Account> privateAccounts = accountService.fetchPrivateAccounts(authToken, true);
        assertTrue(privateAccounts.size() > 0);
        privateAccounts.forEach(privateAccount -> assertNotNull(privateAccount.getBalance()));
    }
    
    @Test
    public void createViewForBankAccount() {
    	List<Account> privateAccounts = accountService.fetchPrivateAccounts(authToken, true);
    	accountService.createViewForBankAcocount(authToken, privateAccounts.get(0));
    	System.out.println("View Created");
    }
    
    @Test
    public void fetchAccountViewsOk() {
    	List<View> views = accountService.fetchAccountViews(authToken);
    	assertTrue(views.size()>0);
    }
}