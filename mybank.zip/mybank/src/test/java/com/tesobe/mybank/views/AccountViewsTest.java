package com.tesobe.mybank.views;

import com.tesobe.mybank.AbstractTestSupport;

public class AccountViewsTest extends AbstractTestSupport{

}
